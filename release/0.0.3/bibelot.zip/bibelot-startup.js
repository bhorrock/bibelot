Hooks.on('ready', () => {
	CONFIG.DND5E.spellSchools['voi'] = 'Void Magic';
});
